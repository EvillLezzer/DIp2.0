﻿using System;
using System.Collections.Generic;

namespace DIP3.Models
{
    public partial class Authorization
    {
        public int Id { get; set; }
        public string Login { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string Role { get; set; } = null!;
    }
}
