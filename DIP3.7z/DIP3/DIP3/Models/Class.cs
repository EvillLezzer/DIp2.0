﻿using System;
using System.Collections.Generic;

namespace DIP3.Models
{
    public partial class Class
    {
        public Class()
        {
            Lessions = new HashSet<Lession>();
        }

        public int Id { get; set; }
        public string ClassName { get; set; } = null!;
        public int ClassTeacher { get; set; }

        public virtual Teacher ClassTeacherNavigation { get; set; } = null!;
        public virtual ICollection<Lession> Lessions { get; set; }
    }
}
