﻿using System;
using System.Collections.Generic;

namespace DIP3.Models
{
    public partial class Lession
    {
        public int Id { get; set; }
        public string Lession1 { get; set; } = null!;
        public string Subject { get; set; } = null!;
        public int TeachersId { get; set; }
        public int WeekdayId { get; set; }
        public int ClassId { get; set; }

        public virtual Class Class { get; set; } = null!;
        public virtual Teacher Teachers { get; set; } = null!;
        public virtual TableWeekday Weekday { get; set; } = null!;
    }
}
