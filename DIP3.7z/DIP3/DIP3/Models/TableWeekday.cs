﻿using System;
using System.Collections.Generic;

namespace DIP3.Models
{
    public partial class TableWeekday
    {
        public TableWeekday()
        {
            Lessions = new HashSet<Lession>();
        }

        public int Id { get; set; }
        public string Weekday { get; set; } = null!;

        public virtual ICollection<Lession> Lessions { get; set; }
    }
}
