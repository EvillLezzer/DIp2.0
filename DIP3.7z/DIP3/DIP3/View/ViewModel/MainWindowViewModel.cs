﻿using DIP3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIP3.View.ViewModel
{
    public class MainWindowViewModel : ViewModelBase
    {
        private List<Class> _classes;
        private List<Class> _displayingClasses;
        private Class _selectedClasses;
      


        public Class SelectedClasses
        {
            get => _selectedClasses;
            set => Set(ref _selectedClasses, value, nameof(SelectedClasses));
        }
        public List<Class> DisplayingClasses
        {
            get => _displayingClasses;
            set => Set(ref _displayingClasses, value, nameof(DisplayingClasses));
        }

        public MainWindowViewModel()
        {
            using BDContext _context = new BDContext();
            {
                _classes = _context.Classes.ToList();

            }
            _displayingClasses = new List<Class>(_classes);
        }


        public List<string> Classesname => new List<string>
        {
           "Без Сортировки","9-","8-","7-","6-","5-","4-","3-","2-","1-"
        };

        private string _tablename;
        public string Tablename
        {

            get => _tablename;
            set { Set(ref _tablename, value, nameof(Tablename)); Vivod(); }

        }

        private List<Class> Filter(List<Class> tableWeekdays)
        {
            if (Tablename == Classesname[1])
                return tableWeekdays.Where(p => p.ClassName.StartsWith('9')).ToList();
            else if (Tablename == Classesname[2])
                return tableWeekdays.Where(p => p.ClassName.StartsWith('8')).ToList();
            if (Tablename == Classesname[3])
                return tableWeekdays.Where(p => p.ClassName.StartsWith('7')).ToList();
            else if (Tablename == Classesname[4])
                return tableWeekdays.Where(p => p.ClassName.StartsWith('6')).ToList();
            if (Tablename == Classesname[5])
                return tableWeekdays.Where(p => p.ClassName.StartsWith('5')).ToList();
            else if (Tablename == Classesname[6])
                return tableWeekdays.Where(p => p.ClassName.StartsWith('4')).ToList();
            if (Tablename == Classesname[7])
                return tableWeekdays.Where(p => p.ClassName.StartsWith('3')).ToList();
            else if (Tablename == Classesname[8])
                return tableWeekdays.Where(p => p.ClassName.StartsWith('2')).ToList();
            if (Tablename == Classesname[9])
                return tableWeekdays.Where(p => p.ClassName.StartsWith('1')).ToList();
            else return tableWeekdays;

            



        }

        private void Vivod()
        {

            DisplayingClasses = Filter(_classes);

        }
    }
}
