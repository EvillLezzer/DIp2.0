﻿using DIP3.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Xml.Linq;

namespace DIP3.View.ViewModel
{
    public class SchedulesWindowViewModel : ViewModelBase
    {
               


    }
}
